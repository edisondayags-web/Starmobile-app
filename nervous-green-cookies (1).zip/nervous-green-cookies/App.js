import { extract_merchant_name } from 'rust-qr-core';
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal, FlatList, Alert, Linking, SafeAreaView, StatusBar, ScrollView } from 'react-native';
import { CameraView, Camera } from 'expo-camera';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Animated, { useSharedValue, withSequence, withTiming, useAnimatedStyle, withDelay } from 'react-native-reanimated';
import { Audio } from 'expo-av';

// ===== FIREBASE + CRASHLYTICS =====
import { initializeApp } from 'firebase/app';
import { getFirestore, doc, onSnapshot, increment, updateDoc, setDoc, collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { getAnalytics, logEvent } from 'firebase/analytics';
import * as Crashlytics from 'expo-firebase-crashlytics';
const brandPink = '#FF4D8D';
const brandPinkDark = '#D6336C';
const brandPinkLight = '#FFB3CB';

const firebaseConfig = {
  apiKey: "AIza...PALITAN_MO",
  authDomain: "yourapp.firebaseapp.com",
  projectId: "yourapp",
  storageBucket: "yourapp.appspot.com",
  messagingSenderId: "123456",
  appId: "1:123456:web:abc123"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const analytics = getAnalytics(app);

// ===== WALLETS WITH BRAND COLORS =====
const WALLETS_RAW = [
  { name: 'BDO', deeplink: 'bdo://', store: 'com.bdo.unibank', color: '#0033A0' },
  { name: 'BPI', deeplink: 'bpi://', store: 'com.bpi.mobile', color: '#A12830' },
  { name: 'Chinabank', deeplink: 'chinabank://', store: 'com.chinabank.mobile', color: '#E31837' },
  { name: 'GCash', deeplink: 'gcash://qrcode/scan', store: 'com.globe.gcash.android', color: '#007DFE' },
  { name: 'GrabPay', deeplink: 'grab://', store: 'com.grabtaxi.passenger', color: '#00B14F' },
  { name: 'Landbank', deeplink: 'landbank://', store: 'com.landbank.mobile', color: '#006937' },
  { name: 'Maya', deeplink: 'maya://qr', store: 'com.paymaya', color: '#00D631' },
  { name: 'Metrobank', deeplink: 'metrobank://', store: 'com.metrobank.mobile', color: '#002A5C' },
  { name: 'PNB', deeplink: 'pnb://', store: 'com.pnb.mobile', color: '#0066B3' },
  { name: 'RCBC', deeplink: 'rcbc://', store: 'com.rcbc.mobile', color: '#003087' },
  { name: 'Security Bank', deeplink: 'securitybank://', store: 'com.securitybank.mobile', color: '#009CDE' },
  { name: 'ShopeePay', deeplink: 'shopee://', store: 'com.shopee.ph', color: '#EE4D2D' },
  { name: 'UnionBank', deeplink: 'unionbank://', store: 'com.unionbank.ph', color: '#FF7F00' },
];
const WALLETS_SORTED = WALLETS_RAW.sort((a, b) => a.name.localeCompare(b.name));

export default function App() {
  const [hasPermission, setHasPermission] = useState(null);
  const [scanned, setScanned] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showLiveStats, setShowLiveStats] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showQRList, setShowQRList] = useState(false);
  const [showWalletSelect, setShowWalletSelect] = useState(false);
  const [currentQR, setCurrentQR] = useState(null);
  const [savedQRs, setSavedQRs] = useState([]);
  const [sound, setSound] = useState();
  const [liveStats, setLiveStats] = useState({
    total_app_select_clicks: 0,
    selected_BDO: 0,
    selected_BPI: 0,
    selected_Chinabank: 0,
    selected_GCash: 0,
    selected_GrabPay: 0,
    selected_Landbank: 0,
    selected_Maya: 0,
    selected_Metrobank: 0,
    selected_PNB: 0,
    selected_RCBC: 0,
    selected_Security_Bank: 0,
    selected_ShopeePay: 0,
    selected_UnionBank: 0,
    selected_QRPH_Default: 0,
  });

  useEffect(() => {
    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === 'granted');
      loadSavedQRs();

      Crashlytics.setUserId('anonymous_user');
      Crashlytics.log('UR scanner launched');
      logEvent(analytics, 'app_open');

      try {
        const { sound } = await Audio.Sound.createAsync(
          { uri: 'https://cdn.pixabay.com/audio/2022/03/15/audio_2b28b2e3e1.mp3' }
        );
        setSound(sound);
      } catch (e) {
        Crashlytics.recordError(e);
      }
    })();
  }, []);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'live_stats', 'summary'),
      (doc) => {
        if (doc.exists()) {
          setLiveStats(doc.data());
        } else {
          setDoc(doc.ref, liveStats);
        }
      },
      (error) => {
        Crashlytics.recordError(error);
      }
    );
    return () => unsub();
  }, []);

  const loadSavedQRs = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('qr_list');
      if (jsonValue != null) {
        setSavedQRs(JSON.parse(jsonValue));
      }
    } catch (e) {
      Crashlytics.recordError(e);
    }
  };

  const isValidQRPH = (data) => {
    if (!data || data.length > 512) return false;
    if (!data.startsWith('000201')) return false;
    if (!data.includes('63')) return false;
    return true;
  };

  const extractMerchantName = (qrData) => {
    try {
      return extract_merchant_name(qrData);
    } catch (e) {
      Crashlytics.recordError(e);
      return 'Unknown Merchant';
    }
  };

  const saveQRToList = async (qrData) => {
    try {
      const qrName = extractMerchantName(qrData);
      const qrItem = {
        name: qrName,
        data: qrData,
        date: new Date().toISOString(),
      };
      const existingQRs = await AsyncStorage.getItem('qr_list');
      let qrList = existingQRs ? JSON.parse(existingQRs) : [];
      const exists = qrList.some((item) => item.data === qrData);
      if (!exists) {
        qrList.unshift(qrItem);
        await AsyncStorage.setItem('qr_list', JSON.stringify(qrList));
        setSavedQRs(qrList);
      }
    } catch (e) {
      Crashlytics.recordError(e);
    }
  };

  const handleBarCodeScanned = async ({ data }) => {
    if (!scanned) {
      if (!isValidQRPH(data)) {
        Crashlytics.recordError(new Error('Invalid QRPH scanned'));
        Alert.alert('Invalid QR', 'Hindi ito valid QRPH code. Baka scam.');
        return;
      }

      setScanned(true);
      setCurrentQR(data);
      saveQRToList(data);
      setShowWalletSelect(true);
      Crashlytics.log(`QR Scanned: ${extractMerchantName(data)}`);
      logEvent(analytics, 'qr_scanned');
    }
  };

  const handleWalletSelect = async (walletName) => {
    const now = Date.now();
    const lastClick = await AsyncStorage.getItem('lastClickTime');

    if (lastClick && now - parseInt(lastClick) < 5000) {
      Alert.alert('Slow down', 'Wait 5 seconds before next selection');
      return;
    }

    await AsyncStorage.setItem('lastClickTime', now.toString());
    setShowWalletSelect(false);

    try {
      Crashlytics.log(`User clicked 'Open in ${walletName}'`);
      logEvent(analytics, 'wallet_select', { wallet: walletName });

      const safeFieldName = `selected_${walletName.replace(/\s/g, '_')}`;

      try {
        await updateDoc(doc(db, 'live_stats', 'summary'), {
          total_app_select_clicks: increment(1),
          [safeFieldName]: increment(1)
        });
      } catch (error) {
        const pending = await AsyncStorage.getItem('pending_clicks');
        const list = pending ? JSON.parse(pending) : [];
        list.push({ wallet: walletName, timestamp: Date.now() });
        await AsyncStorage.setItem('pending_clicks', JSON.stringify(list));
        Crashlytics.recordError(error);
      }

      await addDoc(collection(db, 'click_logs'), {
        action: `clicked_open_in_${walletName}`,
        merchant: extractMerchantName(currentQR),
        qr_hash: currentQR.slice(-6),
        timestamp: serverTimestamp(),
        disclaimer: 'User clicked button only. No payment confirmed.'
      });

      if (walletName === 'QRPH_Default') {
        await Linking.openURL(`https://qrph.co?data=${encodeURIComponent(currentQR)}`);
      } else {
        const wallet = WALLETS_RAW.find(w => w.name === walletName);
        try {
          await Linking.openURL(wallet.deeplink);
        } catch {
          Alert.alert(
            `${walletName} not installed`,
            'Install from Play Store?',
            [
              { text: 'Cancel' },
              { text: 'Install', onPress: () => Linking.openURL(`market://details?id=${wallet.store}`) }
            ]
          );
        }
      }

    } catch (error) {
      Crashlytics.recordError(error);
      Alert.alert('Error', 'Hindi ma-open ang app');
    }
    setTimeout(() => setScanned(false), 2000);
  };

  const deleteQR = async (index) => {
    try {
      const newList = [...savedQRs];
      newList.splice(index, 1);
      await AsyncStorage.setItem('qr_list', JSON.stringify(newList));
      setSavedQRs(newList);
    } catch (e) {
      Crashlytics.recordError(e);
    }
  };

  const openQR = async (qrData) => {
    setShowQRList(false);
    setCurrentQR(qrData);
    setShowWalletSelect(true);
  };

  if (hasPermission === null) {
    return <View style={styles.container}><Text>Requesting camera permission</Text></View>;
  }
  if (hasPermission === false) {
    return <View style={styles.container}><Text>No access to camera</Text></View>;
  }

  const wavyStats = [
    { label: "Total App Select Clicks", value: liveStats.total_app_select_clicks, color: "#FFD600" },
    ...WALLETS_SORTED.map(w => ({
      label: `Selected ${w.name}`,
      value: liveStats[`selected_${w.name.replace(/\s/g, '_')}`] || 0,
      color: w.color
    })),
    { label: "Selected Other QRPH Apps", value: liveStats.selected_QRPH_Default || 0, color: "#888" },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      <CameraView
        style={StyleSheet.absoluteFillObject}
        onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
        barcodeScannerSettings={{ barcodeTypes: ['qr'] }}
      />

      <TouchableOpacity style={styles.settingsBtn} onPress={() => setShowSettings(true)}>
        <Text style={styles.iconText}>⚙️</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.qrListBtn} onPress={() => setShowQRList(true)}>
        <Text style={styles.qrListText}>QR LIST</Text>
      </TouchableOpacity>

      <Modal visible={showWalletSelect} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.walletModalContent}>
            <Text style={styles.modalTitle}>Choose app to open:</Text>
            <Text style={styles.disclaimerNeutral}>
              UR scanner is not affiliated with any bank or e-wallet.
              Select your preferred app to continue.
            </Text>
            <Text style={styles.merchantName}>{currentQR ? extractMerchantName(currentQR) : ''}</Text>

            <ScrollView style={{ maxHeight: 400 }}>
              {WALLETS_SORTED.map((wallet) => (
                <TouchableOpacity
                  key={wallet.name}
                  style={[styles.walletBtnColored, { backgroundColor: wallet.color }]}
                  onPress={() => handleWalletSelect(wallet.name)}
                >
                  <View style={styles.walletBtnContent}>
                    <View style={[styles.walletIcon, { backgroundColor: '#fff' }]}>
                      <Text style={[styles.walletIconText, { color: wallet.color }]}>
                        {wallet.name.charAt(0)}
                      </Text>
                    </View>
                    <Text style={styles.walletBtnTextColored}>{wallet.name}</Text>
                  </View>
                </TouchableOpacity>
              ))}

              <TouchableOpacity
                style={[styles.walletBtnColored, { backgroundColor: '#555' }]}
                onPress={() => handleWalletSelect('QRPH_Default')}
              >
                <View style={styles.walletBtnContent}>
                  <View style={[styles.walletIcon, { backgroundColor: '#fff' }]}>
                    <Text style={[styles.walletIconText, { color: '#555' }]}>QR</Text>
                  </View>
                  <Text style={styles.walletBtnTextColored}>Other QRPH Apps</Text>
                </View>
              </TouchableOpacity>
            </ScrollView>

            <Text style={styles.legalDisclaimer}>
              *Clicks only. Not confirmed payment. You will choose amount inside your app.
            </Text>

            <TouchableOpacity style={styles.closeBtn} onPress={() => { setShowWalletSelect(false); setScanned(false); }}>
              <Text style={styles.closeBtnText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={showSettings} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            {!showLiveStats && !showAbout && !showPrivacy ? (
              <>
                <Text style={styles.modalTitle}>Settings</Text>
                <TouchableOpacity style={styles.modalItem} onPress={() => setShowLiveStats(true)}>
                  <Text style={styles.modalItemText}>📊 Live Stats</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.modalItem} onPress={() => setShowPrivacy(true)}>
                  <Text style={styles.modalItemText}>🔒 Privacy Policy</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.modalItem} onPress={() => setShowAbout(true)}>
                  <Text style={styles.modalItemText}>ℹ️ About UR scanner</Text>
                </TouchableOpacity>
                <Text style={styles.versionText}>Version 1.0.0</Text>
                <TouchableOpacity style={styles.closeBtn} onPress={() => setShowSettings(false)}>
                  <Text style={styles.closeBtnText}>Close</Text>
                </TouchableOpacity>
              </>
            ) : showLiveStats ? (
              <>
                <Text style={styles.modalTitle}>Live Stats</Text>
                <Text style={styles.statsHeader}>*Clicks only. Not confirmed payment.*</Text>
                <ScrollView style={{ maxHeight: 400, marginVertical: 10 }}>
                  {wavyStats.map((stat, idx) => (
                    <WavyStatRow
                      key={idx}
                      label={stat.label}
                      value={stat.value.toLocaleString()}
                      color={stat.color}
                      sound={sound}
                    />
                  ))}
                </ScrollView>
                <TouchableOpacity style={styles.closeBtn} onPress={() => setShowLiveStats(false)}>
                  <Text style={styles.closeBtnText}>Back</Text>
                </TouchableOpacity>
              </>
            ) : showPrivacy ? (
              <>
                <Text style={styles.modalTitle}>Privacy Policy</Text>
                <ScrollView style={{ maxHeight: 400, marginVertical: 10 }}>
                  <Text style={styles.privacyHeader}>UR Scanner Privacy Policy</Text>
                  <Text style={styles.privacyDeveloper}>Developer: EDISON SUCLATAN DAYAGUIT</Text>
                  <Text style={styles.privacyDate}>Last Updated: 2026-01-24</Text>

                  <Text style={styles.privacySubHeader}>1. Information We Collect</Text>
                  <Text style={styles.aboutText}>
                    - QR Code Data: We temporarily process QR codes you scan to extract merchant name only. We do not store full QR data.{'\n'}
                    - Click Analytics: We count which bank or e-wallet you select to improve the app. No payment amounts recorded.{'\n'}
                    - Device Data: Anonymous crash logs via Firebase Crashlytics to fix bugs.
                  </Text>

                  <Text style={styles.privacySubHeader}>2. How We Use Data</Text>
                  <Text style={styles.aboutText}>
                    - To redirect you to your chosen bank or e-wallet app{'\n'}
                    - To show live statistics of app usage{'\n'}
                    - To fix crashes and improve performance
                  </Text>

                  <Text style={styles.privacySubHeader}>3. Data We DON'T Collect</Text>
                  <Text style={styles.aboutText}>
                    - Bank account numbers{'\n'}
                    - PINs or passwords{'\n'}
                    - Payment amounts{'\n'}
                    - Personal identity{'\n'}
                    - Location data{'\n'}
                    - Contacts or photos
                  </Text>

                  <Text style={styles.privacySubHeader}>4. Third Parties</Text>
                  <Text style={styles.aboutText}>
                    - Firebase Analytics: Anonymous usage stats{'\n'}
                    - Firebase Crashlytics: Crash reports only{'\n'}
                    - No data is sold to advertisers
                  </Text>

                  <Text style={styles.privacySubHeader}>5. Your Rights</Text>
                  <Text style={styles.aboutText}>
                    - You can delete saved QR list anytime in-app{'\n'}
                    - You can uninstall to stop all data collection{'\n'}
                    - Contact: edisondayags@gmail.com for data requests
                  </Text>

                  <Text style={styles.privacySubHeader}>6. Children's Privacy</Text>
                  <Text style={styles.aboutText}>
                    This app is not intended for children under 13. We do not knowingly collect data from children.
                  </Text>

                  <Text style={styles.privacySubHeader}>7. Changes</Text>
                  <Text style={styles.aboutText}>
                    We may update this policy. Check this page for latest version.
                  </Text>

                  <Text style={styles.aboutDivider}>──────────────</Text>
                  <Text style={styles.aboutText}>
                    UR Scanner does not process payments. You are redirected to your chosen bank or e-wallet which has its own privacy policy.
                  </Text>
                  <Text style={styles.aboutText}>
                    {'\n'}Developer: EDISON SUCLATAN DAYAGUIT{'\n'}San Antonio Adtuyon Pangantucan Bukidnon
                  </Text>
                </ScrollView>
                <TouchableOpacity style={styles.closeBtn} onPress={() => setShowPrivacy(false)}>
                  <Text style={styles.closeBtnText}>Back</Text>
                </TouchableOpacity>
              </>
            ) : (
              <>
                <Text style={styles.modalTitle}>About UR scanner</Text>
                <ScrollView style={{ maxHeight: 400, marginVertical: 10 }}>
                  <Text style={styles.aboutText}>
                    UR scanner is a QRPH reader app that helps users open QR codes in their preferred bank or e-wallet app.
                  </Text>
                  <Text style={styles.aboutText}>
                    {'\n'}This app does not process payments, store funds, or hold user money. It only redirects to your chosen app.
                  </Text>
                  <Text style={styles.aboutText}>
                    {'\n'}*Clicks only. Not confirmed payment. You will choose amount inside your app.
                  </Text>
                  <Text style={styles.aboutDivider}>──────────────</Text>
                  <Text style={styles.aboutDeveloper}>Developer:</Text>
                  <Text style={styles.aboutName}>EDISON SUCLATAN DAYAGUIT</Text>
                  <Text style={styles.aboutAddress}>San Antonio Adtuyon Pangantucan Bukidnon</Text>
                  <Text style={styles.aboutText}>
                    {'\n'}UR scanner is not affiliated with any bank or e-wallet.
                  </Text>
                  <Text style={styles.aboutQuote}>
                    {'\n'}Yun lang para maintindihan nyo talaga and mabuhay kayo 3x a day mga ka inspirasyon
                  </Text>
                </ScrollView>
                <TouchableOpacity style={styles.closeBtn} onPress={() => setShowAbout(false)}>
                  <Text style={styles.closeBtnText}>Back</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>

      <Modal visible={showQRList} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.listModalContent}>
            <Text style={styles.listTitle}>QR LIST - Tap to open</Text>
            {savedQRs.length === 0 ? (
              <View style={styles.emptyContainer}>
                <Text style={styles.emptyText}>No saved QR yet</Text>
              </View>
            ) : (
              <FlatList
                data={savedQRs}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item, index }) => (
                  <TouchableOpacity style={styles.qrItem} onPress={() => openQR(item.data)}>
                    <View style={styles.qrItemLeft}>
                      <Text style={styles.qrItemName}>{item.name}</Text>
                      <Text style={styles.qrItemDate}>Saved: {item.date.substring(0, 10)}</Text>
                    </View>
                    <TouchableOpacity onPress={() => deleteQR(index)}>
                      <Text style={styles.deleteText}>🗑️</Text>
                    </TouchableOpacity>
                  </TouchableOpacity>
                )}
              />
            )}
            <TouchableOpacity style={styles.closeBtn} onPress={() => setShowQRList(false)}>
              <Text style={styles.closeBtnText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const WavyStatRow = ({ label, value, color, sound }) => {
  const fullText = `${label} = ${value}`;

  useEffect(() => {
    const interval = setInterval(() => {
      if (sound) sound.replayAsync();
    }, 5000);
    return () => clearInterval(interval);
  }, [sound]);

  return (
    <View style={styles.wavyRow}>
      {fullText.split('').map((char, index) => {
        const isNumber = !isNaN(char) && char !== ' ';
        return (
          <WavyChar
            key={index}
            char={char}
            index={index}
            textColor={isNumber ? color : '#FFFFFF'}
          />
        );
      })}
    </View>
  );
}

const WavyChar = ({ char, index, textColor }) => {
  const translateY = useSharedValue(0);

  useEffect(() => {
    const blowWind = () => {
      translateY.value = withSequence(
        withDelay(index * 30, withTiming(-6, { duration: 150 })),
        withTiming(6, { duration: 300 }),
        withTiming(0, { duration: 150 })
      );
    };
    blowWind();
    const interval = setInterval(blowWind, 5000);
    return () => clearInterval(interval);
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
  }));

  return (
    <Animated.Text style={[styles.wavyChar, { color: textColor }, animatedStyle]}>
      {char}
    </Animated.Text>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  settingsBtn: { position: 'absolute', top: 50, left: 20, width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  iconText: { fontSize: 24 },
  qrListBtn: { position: 'absolute', top: 50, right: 20, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, backgroundColor: brandPinkDark },
  qrListText: { color: '#fff', fontWeight: 'bold' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { width: '85%', maxHeight: '80%', backgroundColor: '#1a1a1a', borderRadius: 12, padding: 20 },
  walletModalContent: { width: '85%', maxHeight: '80%', backgroundColor: '#1a1a1a', borderRadius: 12, padding: 20 },
  merchantName: { color: brandPinkLight, fontSize: 14, textAlign: 'center', marginBottom: 8 },
  disclaimerNeutral: { color: '#AAA', fontSize: 11, textAlign: 'center', marginBottom: 12, fontStyle: 'italic' },
  walletBtnColored: {
    padding: 12,
    borderRadius: 10,
    marginVertical: 5,
    elevation: 2,
  },
  walletBtnContent: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  walletIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12
  },
  walletIconText: {
    fontWeight: '900',
    fontSize: 16
  },
  walletBtnTextColored: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2
  },
  legalDisclaimer: { color: '#777', fontSize: 10, textAlign: 'center', marginTop: 12, fontStyle: 'italic' },
  modalTitle: { color: '#fff', fontSize: 20, fontWeight: 'bold', marginBottom: 8, textAlign: 'center' },
  modalItem: { paddingVertical: 12 },
  modalItemText: { color: '#fff', fontSize: 16 },
  versionText: { color: '#999', fontSize: 14, marginTop: 8 },
  closeBtn: { marginTop: 16, padding: 12, backgroundColor: '#333', borderRadius: 8, alignItems: 'center' },
  closeBtnText: { color: '#fff', fontWeight: 'bold' },
  listModalContent: { width: '90%', height: '70%', backgroundColor: '#1a1a1a', borderRadius: 12, padding: 16 },
  listTitle: { color: brandPink, fontSize: 18, fontWeight: 'bold', marginBottom: 16 },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyText: { color: '#999', fontSize: 16 },
  qrItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#333' },
  qrItemLeft: { flex: 1 },
  qrItemName: { color: brandPinkLight, fontSize: 16, fontWeight: 'bold' },
  qrItemDate: { color: '#999', fontSize: 12, marginTop: 4 },
  deleteText: { fontSize: 24 },
  statsHeader: { color: '#FFD600', fontSize: 10, fontWeight: 'bold', marginBottom: 6, textAlign: 'center' },
  wavyRow: { flexDirection: 'row', marginVertical: 2, flexWrap: 'wrap' },
  wavyChar: { fontSize: 11, fontWeight: '600' },
  aboutText: {
    color: '#CCC',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 8,
    textAlign: 'left'
  },
  aboutDivider: {
    color: '#555',
    fontSize: 12,
    textAlign: 'center',
    marginVertical: 12
  },
  aboutDeveloper: {
    color: '#AAA',
    fontSize: 11,
    textAlign: 'center',
    marginBottom: 4
  },
  aboutName: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 4
  },
  aboutAddress: {
    color: '#AAA',
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 12
  },
  aboutQuote: {
    color: brandPinkLight,
    fontSize: 13,
    fontStyle: 'italic',
    textAlign: 'center',
    marginTop: 12,
    lineHeight: 18
  },
  privacyHeader: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 4
  },
  privacyDeveloper: {
    color: '#CCC',
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 2
  },
  privacyDate: {
    color: '#AAA',
    fontSize: 11,
    textAlign: 'center',
    marginBottom: 12
  },
  privacySubHeader: {
    color: brandPinkLight,
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: 12,
    marginBottom: 6
  },
});
